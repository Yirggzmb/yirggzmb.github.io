Verdant Shores
Map created by Yirggzmb
------------------------

Verdant Shores is a small labor of love for a game I think is pretty cool and definitely
could use some more custom content. It took me about a month of work and I've done my
best to channel some of the vibes from old sims neighborhoods by giving ever custom 
household a little story, some more involved than others. This is a very large map 
compared to the ones included with the game, so while I've had no problems with it on
my end, ymmv if your computer is a bit older.

Shoutout to my friends Batronyx, Dmynerd, and Selah for designing little avatars I could
force to buss tables and such

There's two easter eggs featuring families *loosely* based on other video games I enjoy.
Names have been changed of course, but see if you can find them. ;D

-------------------------------

If you discover any problems with the map, feel free to poke me on socials!

Mastodon - @yirggzmb@lasersare.fun
Twitter - @Yirggzmb

You can also just @ me in the Ellpeck dicord

-------------------------------

The postcard is my own art. It is sized so that you should be able to get it printed and
use it as a REAL postcard if you'd like. This is explicit permission to do so for personal
use. Included is both a version with and without text. ^_^

-------------------------------

Happy playing! <3